
/* $begin echoserverimain */
#include "csapp.h"

#define NTHREADS 100
#define SBUFSIZE 8192

/* $begin sbuft */
typedef struct {
    int *buf;          /* Buffer array */         
    int n;             /* Maximum number of slots */
    int front;         /* buf[(front+1)%n] is first item */
    int rear;          /* buf[rear%n] is last item */
    sem_t mutex;       /* Protects accesses to buf */
    sem_t slots;       /* Counts available slots */
    sem_t items;       /* Counts available items */
} sbuf_t;
/* $end sbuft */

struct item{
    int ID;
    int left_stock;
    int price;
    int readcnt;
    sem_t mutex, w;
};

struct node {
	struct item data;
	struct node *left, *right;
};

typedef struct node *tree_pointer;
tree_pointer root = NULL;
sbuf_t sbuf;
static int byte_cnt; /* Byte counter */
static sem_t mutex; /* and the mutex that protects it */
char showStock[MAXLINE];

tree_pointer insertNode(tree_pointer ptr, int newID, int newLeft, int newPrice);
void print_inorder(char *update, tree_pointer ptr);
void free_tree(tree_pointer ptr);
void stockBufClear();
void sbuf_init(sbuf_t *sp, int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp, int item);
int sbuf_remove(sbuf_t *sp);
tree_pointer search(tree_pointer ptr, int id);
void *thread(void *vargp);
static int byte_cnt;
void stock_server(int connfd);
void show(int connfd, tree_pointer ptr);
void buy(int connfd, tree_pointer ptr, int id, int count);
void sell(int connfd, tree_pointer ptr, int id, int count);
void close_client(int connfd);


int main(int argc, char **argv) 
{
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    pthread_t tid; 
    

    char client_hostname[MAXLINE], client_port[MAXLINE];
    FILE* fp = fopen("stock.txt", "r");

    if(fp == NULL) {
		fprintf(stderr, "file does not exist. \n");
		exit(0);
	}
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }
    while(!feof(fp)) {
            int id, left, price;
            if (fscanf(fp, "%d %d %d", &id, &left, &price) <0 ) break;
            root = insertNode(root, id, left, price);
        }
    fclose(fp);

    listenfd = Open_listenfd(argv[1]);
    sbuf_init(&sbuf, SBUFSIZE); 
    for (int i = 0; i < NTHREADS; i++)  
	    Pthread_create(&tid, NULL, thread, NULL);              


    while (1) { 
        clientlen = sizeof(struct sockaddr_storage);
        connfd = Accept(listenfd, (SA *) &clientaddr, &clientlen);
        Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
		printf("Connected to (%s, %s)\n", client_hostname, client_port);
        sbuf_insert(&sbuf, connfd); /* Insert connfd in buffer */
    }
    sbuf_deinit(&sbuf);
    free_tree(root);
    exit(0);
}
/* $end echoserverimain */


tree_pointer insertNode(tree_pointer ptr, int id, int left, int price) {
	if(ptr == NULL) {
		ptr = (tree_pointer)malloc(sizeof(*ptr));
		ptr->data.ID = id;
		ptr->data.left_stock = left;
		ptr->data.price = price;
		ptr->left = NULL;
		ptr->right = NULL;
        ptr->data.readcnt = 0;
		Sem_init(&ptr->data.mutex, 0, 1);
		Sem_init(&ptr->data.w, 0, 1);
	}
	else if(ptr->data.ID < id) {
		ptr->right = insertNode(ptr->right, id, left, price);
	}
	else if(ptr->data.ID > id) {
		ptr->left = insertNode(ptr->left, id, left, price);
	}
	return ptr;
}

void print_inorder(char *update, tree_pointer ptr) {
	char temp[MAXLINE] = "";
	if(ptr) {
		print_inorder(update, ptr->left);
		sprintf(temp, "%d %d %d\n", ptr->data.ID, ptr->data.left_stock, ptr->data.price);
		strcat(update,temp);
		print_inorder(update, ptr->right);
	}
}


void free_tree(tree_pointer ptr){
	if(ptr){
		free_tree(ptr->left);
		free(ptr);
		free_tree(ptr->right);
	}
}

void stockBufClear(){
	for(int i=0; i<MAXLINE; i++){
		showStock[i] = '\0';
	}
}

/* $begin sbuf_init */
void sbuf_init(sbuf_t *sp, int n)
{
    sp->buf = Calloc(n, sizeof(int)); 
    sp->n = n;                       /* Buffer holds max of n items */
    sp->front = sp->rear = 0;        /* Empty buffer iff front == rear */
    Sem_init(&sp->mutex, 0, 1);      /* Binary semaphore for locking */
    Sem_init(&sp->slots, 0, n);      /* Initially, buf has n empty slots */
    Sem_init(&sp->items, 0, 0);      /* Initially, buf has zero data items */
}
/* $end sbuf_init */

/* Clean up buffer sp */
/* $begin sbuf_deinit */
void sbuf_deinit(sbuf_t *sp)
{
    Free(sp->buf);
}
/* $end sbuf_deinit */

/* Insert item onto the rear of shared buffer sp */
/* $begin sbuf_insert */
void sbuf_insert(sbuf_t *sp, int item)
{
    P(&sp->slots);                          /* Wait for available slot */
    P(&sp->mutex);                          /* Lock the buffer */
    sp->buf[(++sp->rear)%(sp->n)] = item;   /* Insert the item */
    V(&sp->mutex);                          /* Unlock the buffer */
    V(&sp->items);                          /* Announce available item */
}
/* $end sbuf_insert */

/* Remove and return the first item from buffer sp */
/* $begin sbuf_remove */
int sbuf_remove(sbuf_t *sp)
{
    int item;
    P(&sp->items);                          /* Wait for available item */
    P(&sp->mutex);                          /* Lock the buffer */
    item = sp->buf[(++sp->front)%(sp->n)];  /* Remove the item */
    V(&sp->mutex);                          /* Unlock the buffer */
    V(&sp->slots);                          /* Announce available slot */
    return item;
}
/* $end sbuf_remove */
/* $end sbufc */

tree_pointer search(tree_pointer ptr, int id){
	// different
	while(ptr && ptr->data.ID != id) {
		if(ptr->data.ID > id) ptr = ptr->left;
		else ptr = ptr->right;
	}
	// same
	return ptr;

}

void *thread(void *vargp) 
{  
    Pthread_detach(pthread_self()); 
    while (1) { 
        int connfd = sbuf_remove(&sbuf); /* Remove connfd from buffer */ 
        stock_server(connfd);                /* Service client */
        Close(connfd);
        
    }
}
/* $end echoservertpremain */

static void init_echo_cnt(void)
{
    Sem_init(&mutex, 0, 1);
    byte_cnt = 0;
}
void stock_server(int connfd) 
{
    int n; 
    char buf[MAXLINE]; 
    rio_t rio;
    static pthread_once_t once = PTHREAD_ONCE_INIT;
    
    Pthread_once(&once, init_echo_cnt); 
    Rio_readinitb(&rio, connfd);        
    while((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
        
        
        char cmd[10];
        int stockID = 0;
	    int stockNum = 0;
        sscanf(buf, "%s %d %d", cmd, &stockID, &stockNum);
        //printf("server received %d bytes on fd %d\n", n, connfd);

        if(!strncmp(cmd,"show",4)){
            show(connfd, root);
            Rio_writen(connfd,showStock,MAXLINE);
            stockBufClear();
        }
        else if(!strncmp(cmd, "buy",3)){
            buy(connfd, root, stockID,stockNum);
        }
        else if(!strncmp(cmd, "sell",4)){
            sell(connfd, root, stockID, stockNum);
        }
        else if(!strncmp(cmd, "exit",4)){
            close_client(connfd);
            return; 
        }
        else{
            Rio_writen(connfd, buf, MAXLINE);
        }
        
       close_client(connfd);
        
    }

}

void show(int connfd, tree_pointer ptr){
	char temp[MAXLINE];
    
	if(ptr){
		show(connfd, ptr->left);

        P(&ptr->data.mutex);
        ptr->data.readcnt++;
        if(ptr->data.readcnt == 1)
            P(&ptr->data.w);
        V(&ptr->data.mutex);

		sprintf(temp,"%d %d %d\n",ptr->data.ID, ptr->data.left_stock, ptr->data.price);
		strcat(showStock,temp); //temp에 있는 것을 showStock에 이어서 저장

        P(&ptr->data.mutex);
        ptr->data.readcnt--;
        if(ptr->data.readcnt == 0)
            V(&ptr->data.w);
        V(&ptr->data.mutex);

		show(connfd,ptr->right);
	}
	
}

void buy(int connfd, tree_pointer ptr, int id, int count){
	ptr = search(ptr, id);
    P(&ptr->data.w);
    

	if(ptr == NULL){
		Rio_writen(connfd, "[buy] Input error!\n", MAXLINE);
	}
	else{
		//남은 수량보다 사려는 개수가 더 크다면 fail
		if(ptr->data.left_stock < count){
			Rio_writen(connfd,"Not enough left stocks\n",MAXLINE);
		}
		else{
			//success
			ptr->data.left_stock -= count;
			Rio_writen(connfd, "[buy] success\n", MAXLINE);
		}
	}

    V(&ptr->data.w);
	
}

void sell(int connfd, tree_pointer ptr, int id, int count){
	ptr = search(ptr, id);
    P(&ptr->data.w);
    


	if(ptr == NULL){
		Rio_writen(connfd, "[sell] Input error!\n", MAXLINE);
	}
	else{
		ptr->data.left_stock += count;
		Rio_writen(connfd, "[sell] success\n", MAXLINE);
	}
    V(&ptr->data.w);
	
}

void close_client(int connfd){
	
	FILE *wfp;

    P(&mutex);

    char update[MAXLINE] = "";
	stockBufClear();
    wfp = fopen("stock.txt","w");
    print_inorder(update, root);
    fprintf(wfp,"%s",update);
    fclose(wfp);

    V(&mutex);
	
}