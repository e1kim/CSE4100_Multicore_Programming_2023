/* 
 * echoserveri.c - An iterative echo server 
 */ 
/* $begin echoserverimain */
#include "csapp.h"



typedef struct {	
	int maxfd;			
	fd_set read_set;	
	fd_set ready_set;	
	int nready;			
	int maxi;			
	int clientNum;
	int clientfd[FD_SETSIZE];		
	rio_t clientrio[FD_SETSIZE];	
} pool;

struct item{
    int ID;
    int left_stock;
    int price;
    int readcnt;
    sem_t mutex;
};

struct node {
	struct item data;
	struct node *left, *right;
};
typedef struct node *tree_pointer;
tree_pointer root = NULL;

int byte_cnt = 0;
char showStock[MAXLINE];
void echo(int connfd);
tree_pointer insertNode(tree_pointer ptr, int newID, int newLeft, int newPrice);
void print_inorder(char *update, tree_pointer ptr);
void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p);
void check_clients(pool *p);
void stockBufClear();
void show(int connfd, tree_pointer ptr);
tree_pointer search(tree_pointer ptr, int id);
void buy(int connfd, tree_pointer ptr, int id, int count);
void sell(int connfd, tree_pointer ptr, int id, int count);
void close_client(pool *p, int connfd, int num);
void free_tree(tree_pointer ptr);

int main(int argc, char **argv) 
{
	

    int listenfd, connfd;
    socklen_t clientlen;
	int id, left, price;
	static pool pool;

    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE];
    FILE* fp = fopen("stock.txt", "r");

    if(fp == NULL) {
		fprintf(stderr, "file does not exist. \n");
		exit(0);
	}
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }
    
	while(!feof(fp)) {
		if (fscanf(fp, "%d %d %d", &id, &left, &price) <0 ) break;
		root = insertNode(root, id, left, price);
	}
	fclose(fp);

    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);
    while (1) {
        
        pool.ready_set = pool.read_set;
		pool.nready = Select(pool.maxfd+1, &pool.ready_set, NULL, NULL, NULL);
        if(FD_ISSET(listenfd, &pool.ready_set)) {
			clientlen = sizeof(struct sockaddr_storage);
			connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
			Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
			printf("Connected to (%s, %s)\n", client_hostname, client_port);
			add_client(connfd, &pool);
		}
        /* Echo a text line from each ready connected descriptor */ 
	    check_clients(&pool); //line:conc:echoservers:checkclients
        
    }
	free_tree(root);

	

    exit(0);
}
/* $end echoserverimain */

tree_pointer insertNode(tree_pointer ptr, int id, int left, int price) {
	if(ptr == NULL) {
		ptr = (tree_pointer)malloc(sizeof(*ptr));
		ptr->data.ID = id;
		ptr->data.left_stock = left;
		ptr->data.price = price;
		ptr->left = NULL;
		ptr->right = NULL;
	}
	else if(ptr->data.ID < id) {
		ptr->right = insertNode(ptr->right, id, left, price);
	}
	else if(ptr->data.ID > id) {
		ptr->left = insertNode(ptr->left, id, left, price);
	}
	return ptr;
}

void print_inorder(char *update, tree_pointer ptr) {
	char temp[MAXLINE] = "";
	if(ptr) {
		print_inorder(update, ptr->left);
		sprintf(temp, "%d %d %d\n", ptr->data.ID, ptr->data.left_stock, ptr->data.price);
		strcat(update,temp);
		print_inorder(update, ptr->right);
	}
}

void init_pool(int listenfd, pool *p) {
	/* Initially, there are no connected descripotrs */
	int i;
	p->maxi = -1;
	for(i = 0; i < FD_SETSIZE; i++)
		p->clientfd[i] = -1;

	/* Initially, listenfd is only member of select read set */
	p->maxfd = listenfd;
	p->clientNum = 0;
	FD_ZERO(&p->read_set);
	FD_SET(listenfd, &p->read_set);
}
void add_client(int connfd, pool *p) 
{
    int i;
    p->nready--;
    for (i = 0; i < FD_SETSIZE; i++)  /* Find an available slot */
	if (p->clientfd[i] < 0) { 
	    /* Add connected descriptor to the pool */
	    p->clientfd[i] = connfd;                 //line:conc:echoservers:beginaddclient
		p->clientNum++;
	    Rio_readinitb(&p->clientrio[i], connfd); //line:conc:echoservers:endaddclient

	    /* Add the descriptor to descriptor set */
	    FD_SET(connfd, &p->read_set); //line:conc:echoservers:addconnfd

	    /* Update max descriptor and pool highwater mark */
	    if (connfd > p->maxfd) //line:conc:echoservers:beginmaxfd
			p->maxfd = connfd; //line:conc:echoservers:endmaxfd
	    if (i > p->maxi)       //line:conc:echoservers:beginmaxi
			p->maxi = i;       //line:conc:echoservers:endmaxi
	    break;
	}
    if (i == FD_SETSIZE) /* Couldn't find an empty slot */
	app_error("add_client error: Too many clients");
}

void stockBufClear(){
	for(int i=0; i<MAXLINE; i++){
		showStock[i] = '\0';
	}
}

/* $begin check_clients */
void check_clients(pool *p) 
{
    int i, connfd, n;
    char buf[MAXLINE]; 
	
    rio_t rio;
	char cmd[10];
	int stockID = 0;
	int stockNum = 0;

    for (i = 0; (i <= p->maxi) && (p->nready > 0); i++) {
		connfd = p->clientfd[i];
		rio = p->clientrio[i];

		
		if ((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))) { 
			p->nready--;
			if ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0 && strcmp(buf, "exit\n") != 0) {
				
				//printf("Server received %d on fd %d\n", n, connfd);
				
				sscanf(buf, "%s %d %d", cmd, &stockID, &stockNum);
				if(!strcmp(cmd,"show")){
					show(connfd, root);
					Rio_writen(connfd,showStock,MAXLINE);
					stockBufClear();
				}
				else if(!strcmp(cmd, "buy")){
					buy(connfd, root, stockID,stockNum);
				}
				else if(!strcmp(cmd, "sell")){
					sell(connfd, root, stockID, stockNum);
				}
				else if(!strcmp(cmd, "exit")){
					close_client(p, connfd, i);
					break;
				}
				stockBufClear();
				
			}
			/* EOF detected, remove descriptor from pool */
			else { 
				close_client(p, connfd, i);
			}
			
		}
    }
}
/* $end check_clients */

void show(int connfd, tree_pointer ptr){
	char temp[MAXLINE];
	if(ptr){
		
		show(connfd, ptr->left);
		sprintf(temp,"%d %d %d\n",ptr->data.ID, ptr->data.left_stock, ptr->data.price);
		strcat(showStock,temp); //temp에 있는 것을 showStock에 이어서 저장
		show(connfd,ptr->right);
	}
	
}
//id찾기
tree_pointer search(tree_pointer ptr, int id){
	// different
	while(ptr && ptr->data.ID != id) {
		if(ptr->data.ID > id) ptr = ptr->left;
		else ptr = ptr->right;
	}
	// same
	return ptr;

}
void buy(int connfd, tree_pointer ptr, int id, int count){
	ptr = search(ptr, id);

	if(ptr == NULL  ){
		Rio_writen(connfd, "[buy] Input error!\n", MAXLINE);
	}
	else{
		//남은 수량보다 사려는 개수가 더 크다면 fail
		if(ptr->data.left_stock < count){
			Rio_writen(connfd,"Not enough left stocks\n",MAXLINE);
		}
		else{
			//success
			ptr->data.left_stock -= count;
			Rio_writen(connfd, "[buy] success\n", MAXLINE);
		}
	}
	
}

void sell(int connfd, tree_pointer ptr, int id, int count){
	ptr = search(ptr, id);

	if(ptr == NULL){
		Rio_writen(connfd, "[sell] Input error!\n", MAXLINE);
	}
	else{
		ptr->data.left_stock += count;
		Rio_writen(connfd, "[sell] success\n", MAXLINE);
	}
}

void close_client(pool *p, int connfd, int num){
	char update[MAXLINE] = "";
	FILE *wfp;
	Close(connfd); 
	FD_CLR(connfd, &p->read_set); 
	p->clientfd[num] = -1;          
	p->clientNum--;
	stockBufClear();
	if(p->clientNum == 0){
		wfp = fopen("stock.txt","w");
		print_inorder(update, root);
		
		fprintf(wfp,"%s",update);
		fclose(wfp);
	}
	
}



void free_tree(tree_pointer ptr){
	if(ptr){
		free_tree(ptr->left);
		free(ptr);
		free_tree(ptr->right);
	}
}