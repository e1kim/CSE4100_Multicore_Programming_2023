/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your information in the following struct.
 ********************************************************/
team_t team = {
    /* Your student ID */
    "20192134",
    /* Your full name*/
    "EunWon Kim",
    /* Your email address */
    "kew5638@sogang.ac.kr",
};

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8
/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)
#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))



/* Basic constants and macros */
#define WSIZE       4       /* Word and header/footer size (bytes) */ 
#define DSIZE       8       /* Double word size (bytes) */
#define CHUNKSIZE  (1<<12)  /* Extend heap by this amount (bytes) */  
#define CLASSES 13


#define MAX(x, y) ((x) > (y)? (x) : (y))  
#define MIN(x, y) ((x) < (y) ? (x) : (y))

/* Pack a size and allocated bit into a word */
#define PACK(size, alloc)  ((size) | (alloc)) 

/* Read and write a word at address p */
#define GET(p)       (*(unsigned int *)(p))            
#define PUT(p, val)  (*(unsigned int *)(p) = (val) )    
#define SET_P(p,ptr) (*(unsigned int *)(p) = (unsigned int)(ptr))
  
/* Read the size and allocated fields from address p */
#define GET_SIZE(p)  (GET(p) & ~0x7)                   
#define GET_ALLOC(p) (GET(p) & 0x1)


/* Given block ptr bp, compute address of its header and footer */
#define HDRP(bp)       ((char *)(bp) - WSIZE)                      
#define FTRP(bp)       ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE) 

/* Given block ptr bp, compute address of next and previous blocks */
#define NEXT_BLKP(bp)  ((char *)(bp) + GET_SIZE(((char *)(bp) - WSIZE))) 
#define PREV_BLKP(bp)  ((char *)(bp) - GET_SIZE(((char *)(bp) - DSIZE))) 

#define NEXT_P(bp) ((char *)(bp))
#define PREV_P(bp) ((char *)(bp) + WSIZE)

#define NEXT(bp) (*(char **)(bp))
#define PREV(bp) (*(char **)(PREV_P(bp)))
/* $end mallocmacros */

/* Global variables */
static char *heap_listp = 0;  /* Pointer to first block */  
static char **seglist;


int mm_init(void);
void *mm_malloc(size_t size);
void mm_free(void *ptr);
void *mm_realloc(void *ptr, size_t size);



/* Function prototypes for internal helper routines */

static void *extend_heap(size_t words);
static int search_class(size_t size);
static void insert_node(void *ptr, size_t size);
static void delete_node(void *ptr);
static void *coalesce(void *bp);
static void place(void *bp, size_t asize);
static void *find_fit(size_t asize);

int mm_init(void) 
{   
    
    int i;
    
	size_t temp, alloc_size, new_size;
    alloc_size = (CLASSES + 1) * (sizeof(char *));
    temp = ((alloc_size > CHUNKSIZE) ? 
        alloc_size : CHUNKSIZE) / WSIZE;
    new_size = (temp%2 == 0) ? (temp * WSIZE) : ((temp + 1) * WSIZE);
    if ((seglist = mem_sbrk(new_size)) == (void *)-1) return -1;
    
    for (i =0; i< CLASSES; i++){
        seglist[i] = NULL;
    }

    if ((heap_listp = mem_sbrk(4*WSIZE)) == (void *)-1) 
        return -1;
    PUT(heap_listp, 0);                          /* Alignment padding */
    PUT(heap_listp + (1*WSIZE), PACK(DSIZE, 1)); /* Prologue header */ 
    PUT(heap_listp + (2*WSIZE), PACK(DSIZE, 1)); /* Prologue footer */ 
    PUT(heap_listp + (3*WSIZE), PACK(0, 1));     /* Epilogue header */
    heap_listp += DSIZE;                     

    /* Extend the empty heap with a free block of CHUNKSIZE bytes */
    if (extend_heap(CHUNKSIZE/WSIZE) == NULL) 
        return -1;
    return 0;
}
/* 
 * mm_malloc - Allocate a block with at least size bytes of payload 
 */
/* $begin mmmalloc */
void *mm_malloc(size_t size) 
{
  
    size_t asize;      /* Adjusted block size */
    size_t extendsize; /* Amount to extend heap if no fit */
    char *bp;      

    //printf("size: %d\n",size);
    
    if (heap_listp == 0){
        mm_init();
    }
    
    /* Ignore spurious requests */
    if (size == 0)
        return NULL;

    /* Adjust block size to include overhead and alignment reqs. */
    if (size <= DSIZE)                                          
        asize = 2*DSIZE;                                        
    else
        asize = DSIZE * ((size + (DSIZE) + (DSIZE-1)) / DSIZE); 

    /* Search the free list for a fit */
    if ((bp = find_fit(asize)) != NULL) {  
        place(bp, asize);                  
        return bp;
    }
    /* No fit found. Get more memory and place the block */
    extendsize = MAX(asize,CHUNKSIZE);                 
    if ((bp = extend_heap(extendsize/WSIZE)) == NULL)  
        return NULL;     
                                     
    place(bp, asize);                                
    return bp;
} 
/* $end mmmalloc */


/*
 * mm_free - Freeing a block does nothing.
 */
void mm_free(void *bp)
{
 
    if (bp == 0) 
        return;
   
    size_t size = GET_SIZE(HDRP(bp));
  
    if (heap_listp == 0){
        mm_init();
    }
    PUT(HDRP(bp), PACK(size, 0));
    PUT(FTRP(bp), PACK(size, 0));
    insert_node(bp,size);
    coalesce(bp);
}

/*
 * mm_realloc - Implemented simply in terms of mm_malloc and mm_free
 */
void *mm_realloc(void *ptr, size_t size)
{
    void *oldptr = ptr;
    void *newptr;
    size_t copySize, extendsize;
    int rem;
    if (size == 0) {
        mm_free(ptr);
        return 0;
    }
    if (ptr == NULL) {
		return mm_malloc(size);
	}
    
    newptr = ptr;
    copySize = size;

    if (copySize <= DSIZE)                                          
        copySize = 2*DSIZE;                                        
    else
        copySize = DSIZE * ((size + (DSIZE) + (DSIZE-1)) / DSIZE); 

    copySize += 256;
    
    if(GET_SIZE(HDRP(ptr)) < copySize){
        if(GET_ALLOC(HDRP(NEXT_BLKP(ptr))) && GET_SIZE(HDRP(NEXT_BLKP(ptr)))){
            newptr = mm_malloc(copySize);
            if(newptr == NULL)
				return NULL;
            memcpy(newptr, ptr, MIN(size, copySize));
            mm_free(ptr);
        }
        else{
            rem = GET_SIZE(HDRP(ptr)) + 
            GET_SIZE(HDRP(NEXT_BLKP(ptr))) - copySize; 
            // rem은 현재 ptr과 다음 빈 ptr의 사이즈를 더한 뒤 할당하고 남은 사이즈이다
            if(rem < 0){
                extendsize = MAX(CHUNKSIZE/WSIZE, (-1) * rem);
                if ((extend_heap(extendsize)) == NULL)
					return 0;
				rem += extendsize;
            }
            delete_node(NEXT_BLKP(ptr));
            PUT(HDRP(ptr), PACK(copySize + rem, 1));
			PUT(FTRP(ptr), PACK(copySize + rem, 1));
        }
    }
    
    return newptr;
}

static void *extend_heap(size_t words) 
{
    char *bp;
    size_t size;

    /* Allocate an even number of words to maintain alignment */
    size = (words % 2) ? (words+1) * WSIZE : words * WSIZE; 
    if ((long)(bp = mem_sbrk(size)) == -1)  
        return NULL;                                       

    /* Initialize free block header/footer and the epilogue header */
    PUT(HDRP(bp), PACK(size, 0));         /* Free block header */   
    PUT(FTRP(bp), PACK(size, 0));         /* Free block footer */   
    PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1)); /* New epilogue header */ 
    insert_node(bp,size);
    /* Coalesce if the previous block was free */
    return coalesce(bp);                                          
}


static int search_class(size_t size){
    int idx = 0; 

    while ((idx < CLASSES - 1) && (size > 1)) {
        size >>= 1;
        idx++;
    }
    
    return idx;    
    
    
}
static void insert_node(void *ptr, size_t size) {
    int idx = 0;
    void *search_ptr = ptr;
    void *insert_ptr = NULL;
    idx = search_class(size);

    search_ptr = seglist[idx];
    while((search_ptr != NULL) && (size > GET_SIZE(HDRP(search_ptr))) ){
        insert_ptr = search_ptr;
        search_ptr = NEXT(search_ptr);
    }

    if (search_ptr != NULL) {
        if (insert_ptr != NULL) {       
            SET_P(NEXT_P(ptr), search_ptr);   
            SET_P(PREV_P(search_ptr), ptr);    
            SET_P(PREV_P(ptr), insert_ptr);   
            SET_P(NEXT_P(insert_ptr), ptr);  
        } else {                        
            SET_P(NEXT_P(ptr), search_ptr);     
            SET_P(PREV_P(search_ptr), ptr);     
            SET_P(PREV_P(ptr), NULL);          
            seglist[idx] = ptr;      
        }
    } else {
        if (insert_ptr != NULL) {       
            SET_P(NEXT_P(ptr), NULL);           
            SET_P(PREV_P(ptr), insert_ptr);    
            SET_P(NEXT_P(insert_ptr), ptr);  
        } else {                        
            SET_P(NEXT_P(ptr), NULL);          
            SET_P(PREV_P(ptr), NULL);        
            seglist[idx] = ptr;      
        }
    }
    
    return;    
}

static void delete_node(void *ptr) {
    int idx = 0;
    size_t size = GET_SIZE(HDRP(ptr));
    idx = search_class(size);

    if(NEXT(ptr) !=NULL){
        if(PREV(ptr) !=NULL){
            SET_P(PREV_P(NEXT(ptr)), PREV(ptr));
            SET_P(NEXT_P(PREV(ptr)), NEXT(ptr));
        }
        else{
            SET_P(PREV_P(NEXT(ptr)), NULL); 
            seglist[idx] = NEXT(ptr);   
        }
    }
    else{
        if(PREV(ptr) != NULL){
            SET_P(NEXT_P(PREV(ptr)), NULL);   
        }
        else{
            seglist[idx] = NULL;
        }
    }
    return;
}


//free block으로 만드는 경우 앞 뒤 free block이 있는 지 확인한다.
//앞 뒤 free block이 있다면 합치고 기존 앞 뒤의 free block은 seglist에서 제거한다.
//새로운 크기의 free block(합쳐진 blcok)은 다시 seglist에 넣는다.
static void *coalesce(void *bp) 
{
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = GET_SIZE(HDRP(bp));
    
    if (prev_alloc && next_alloc) {            /* Case 1 */
        return bp;
    }

    else if (prev_alloc && !next_alloc) {      /* Case 2 */
        delete_node(bp);
        delete_node(NEXT_BLKP(bp)); //다음 블록 삭제
        size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
        PUT(HDRP(bp), PACK(size, 0));
        PUT(FTRP(bp), PACK(size,0));
    }

    else if (!prev_alloc && next_alloc) {      /* Case 3 */
        delete_node(bp);
        delete_node(PREV_BLKP(bp)); //이전 블록 삭제
        size += GET_SIZE(HDRP(PREV_BLKP(bp)));
        PUT(FTRP(bp), PACK(size, 0));
        PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        bp = PREV_BLKP(bp);
    }

    else {                                     /* Case 4 */
        delete_node(bp);
        delete_node(NEXT_BLKP(bp)); //다음 블록 삭제
        delete_node(PREV_BLKP(bp)); //이전 블록 삭제
        size += GET_SIZE(HDRP(PREV_BLKP(bp))) + 
            GET_SIZE(FTRP(NEXT_BLKP(bp)));
        PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
        bp = PREV_BLKP(bp);
    }

    insert_node(bp,size); //새로운 크기의 블록을 seglist에 추가.
    return bp; 
}

//필요시 free list를 나누는 함수
static void place(void *bp, size_t asize)
{
    size_t csize = GET_SIZE(HDRP(bp));   
    delete_node(bp);
    size_t remainder = csize - asize;

    if (remainder >= (2*DSIZE)) { 
        PUT(HDRP(bp), PACK(asize, 1));
        PUT(FTRP(bp), PACK(asize, 1));
        bp = NEXT_BLKP(bp);
        PUT(HDRP(bp), PACK(remainder, 0));
        PUT(FTRP(bp), PACK(remainder, 0));
        insert_node(bp,(remainder));
    }
    else { 
        PUT(HDRP(bp), PACK(csize, 1));
        PUT(FTRP(bp), PACK(csize, 1));
    }
}



static void *find_fit(size_t asize)
{

    char *bp;

    int idx = 0;
    size_t search_size = asize;
    //seglist에 있는 알맞은 크기의 free block을 찾는다.
    //지금 seglist는 크기가 작은 순부터 큰 순으로 seglist에 나열되고 있다.

    idx = search_class(asize);
    
    while(idx < CLASSES){
        if( ((search_size <=1) && (seglist[idx] != NULL)) || (idx == CLASSES - 1) ){
            bp = seglist[idx];
            while( (bp != NULL) && ((asize > GET_SIZE(HDRP(bp))))){
                bp = NEXT(bp);
            }
            if(bp != NULL){
                return bp;
            }
        }
        search_size >>= 1;
        idx ++;
    }
    return NULL;  /* no fit found */



}



