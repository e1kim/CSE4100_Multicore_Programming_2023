/* $begin shellmain */
#include "csapp.h"
#include<errno.h>
#define MAXARGS   128
#define MAX_HISTORY 1024
#define MAX_COMMAND 1024
#define MAXJOBS 1024 /* max jobs at any point in time */
/* Job states */
#define UNDEF 0 /* undefined */
#define FG 1 /* running in foreground */
#define BG 2 /* running in background */
#define ST 3 /* stopped */
#define DONE 4
#define KILL 5


/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv, char* jobscmdline);
int builtin_command(char **argv); 
char command_history[MAX_HISTORY][MAX_COMMAND];
int num_commands= 0;
char ***parse_cmds(char **argv,int argc);


void print_history(void);
char *get_pre_command(void);
char *get_command_by_num(int num);
void add_command_to_history(char *command);

int return_commands_number(FILE *fp);
void handle_sigint(int sig);
void handle_sigtstp(int sig);
int count_argc(char **argv);
int count_pipeline(char **argv, int argc);
void free_cmd(char ***cmd, int argc);
//phase3
void do_bgfg(char **argv);
void do_jobs(void);
void waitfg(pid_t pid);
void sigchld_handler(int sig);

struct job_t *getjobpid(struct job_t *jobs, pid_t pid);
struct job_t *getjobjid(struct job_t *jobs, int jid);
void clearJob(struct job_t *job);

FILE *wfp;

int nextjid = 1; /* next job ID to allocate */
char sbuf[MAXLINE]; /* for composing sprintf messages */



struct job_t { /* The job struct */
  pid_t pid; /* job PID */
  int jid; /* job ID [1, 2, ...] */
  int state; /* UNDEF, BG, FG, or ST */
  char cmdline[MAXLINE]; /* command line */
};


struct job_t jobs[MAXJOBS]; /* The job list */

void block_signal(int signo) {
    sigset_t sigset;
    sigemptyset(&sigset);
    sigaddset(&sigset, signo);
    sigprocmask(SIG_BLOCK, &sigset, NULL);
}

void unblock_signal(int signo) {
    sigset_t sigset;
    sigemptyset(&sigset);
    sigaddset(&sigset, signo);
    sigprocmask(SIG_UNBLOCK, &sigset, NULL);
}


int maxjid(struct job_t *jobs) {
    int max = 0, i;

    for (i = 0; i < MAXJOBS; i++)
        if (jobs[i].jid > max)
            max = jobs[i].jid;
    return max;
}
void donejob() {

	for(int i = 0; i < MAXJOBS; i++) {
		if(jobs[i].state == DONE) {
			//printf("[%d]\tDone     \t%s\n", jobs[i].jid, jobs[i].cmdline);
			jobs[i].state = UNDEF;
		}
		else if(jobs[i].state == KILL) {
			jobs[i].state = UNDEF;
		}
	}
	int count;
	for(count = MAXJOBS - 1; count > 0; count--) {
		if(jobs[count].state == FG || jobs[count].state == BG || jobs[count].state == ST) {
			break;
		}
		nextjid = count;
	}
}
/*delete job from job list*/

int deletejob(struct job_t *jobs, pid_t pid) {
    int i;

    if (pid < 1)
        return 0;

    for (i = 0; i < MAXJOBS; i++) {
        if (jobs[i].pid == pid) {
            clearJob(&jobs[i]);
            nextjid = maxjid(jobs)+1;
            return 1;
        }
    }
    return 0;
}
//job list init
void initjobs(struct job_t *jobs){
    int i;

    for (i = 0; i < MAXJOBS; i++){
		clearJob(&jobs[i]);
	}
        
}

//job list clear

void clearJob(struct job_t *job) {
    job->pid = 0;
    job->jid = 0;
    job->state = UNDEF;
    job->cmdline[0] = NULL;
}

//add a job to job list

int addjob(struct job_t *jobs, pid_t pid, int state, char *cmdline){
    int i;

    if (pid < 1)
        return 0;
	int verbose = 0;
    for (i = 1; i < MAXJOBS; i++) {
        if (jobs[i].pid == 0) { 
            jobs[i].pid = pid;
            jobs[i].state = state;
            jobs[i].jid = nextjid++;
            if (nextjid > MAXJOBS)
                nextjid = 1;
            strcpy(jobs[i].cmdline, cmdline);
            if (verbose) {
                printf("Added job [%d] %d %s\n", jobs[i].jid, jobs[i].pid, jobs[i].cmdline);
            }
            return 1;
        }
    }
    printf("Tried to create too many jobs\n");
    return 0;
}


pid_t fgpid(struct job_t *jobs)
{
    int i;

    for (i = 0; i < MAXJOBS; i++)
        if (jobs[i].state == FG)
            return jobs[i].pid;
    return 0;
}
int main() 
{
    char cmdline[MAXLINE]; /* Command line */
	Signal(SIGCHLD, sigchld_handler);
	Signal(SIGINT,handle_sigint);
	Signal(SIGTSTP, handle_sigtstp);

	FILE *ofp;
    char filename[] = "history.txt";

	initjobs(jobs);//구조체 초기화
	
    //file open 
    ofp = fopen(filename, "r");
	wfp = fopen(filename, "a");

	num_commands = return_commands_number(ofp);

    while (1) {

		/* Read */
		printf("CSE4100-MP-P3> ");                   
		fgets(cmdline, MAXLINE, stdin); 
		if (feof(stdin))
			exit(0);

		/* Evaluate */
		eval(cmdline);
		donejob();
    } 

	fclose(ofp);
	fclose(wfp);
}
/* $end shellmain */
  
/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
	char ***cmd; // phase2
	int argc;
	int pipeline_num;

    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    

	char jobs_cmd[MAXLINE] = "";
    strcpy(buf, cmdline);
    bg = parseline(buf, argv, jobs_cmd); 
	
	
    if (argv[0] == NULL)  
		return;   /* Ignore empty lines */

    if (argv[0][0] != '!') add_command_to_history(cmdline); //history 명령어인 !는 저장x

	if (!builtin_command(argv)) {
		//quit -> exit(0), & -> ignore, other -> run
		
		argc = count_argc(argv);
		pipeline_num = count_pipeline(argv,argc);

		if (pipeline_num){ //go pipeline 
			block_signal(SIGCHLD);
			cmd = parse_cmds(argv, argc);
			if (!bg){
				pipeLine(cmd,pipeline_num);
			}
			else{
				pipeLine2(cmd,pipeline_num);
			}
			free_cmd(cmd, argc);
			unblock_signal(SIGCHLD);
		}
		else{
			pid = Fork();
			if (pid == 0){ // child process 
				Setpgid(0,0);

				if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
					printf("%s: Command not found.\n", argv[0]);
					exit(0);
				}
			}
		}
		
		if(pid != 0){
			/* Parent waits for foreground job to terminate */
			if (!bg ){ 
				addjob(jobs,pid,FG,jobs_cmd);
				int status;
				

				if (!pipeline_num){
					Waitpid(pid,&status,WUNTRACED);
					
				}
				
				if (WIFEXITED(status)) {
					deletejob(jobs,pid);
				}
				
			}
			else//when there is background process!
			{
				
				addjob(jobs,pid,BG,jobs_cmd);
			}

		}
		
		
    }

	
    return;
}

//history 를 출력하는 함수
void print_history(){

	for (int i=1; i<=num_commands; i++){
		printf("%d  %s",i,command_history[i-1]);
	}


}
//previous commands 를 반환하는 함수
char *get_pre_command(){

	if (num_commands==0){
		printf("No commands\n");
		return NULL;
	}
	return command_history[num_commands-1];
}

//number에 맞는 history를 반환하는 함수
char *get_command_by_num(int num){

	if (num <1 || num >= num_commands){

		printf("Invalid number.\n");
		return NULL;

	}
	return command_history[num-1];


}

//history에 저장
void add_command_to_history(char *command){
	
	if (!strcmp(command_history[num_commands-1] , command)) return; 
	strcpy(command_history[num_commands],command);
	setbuf(wfp, NULL);
	fprintf(wfp,"%s",command);
	num_commands++;


}

//history: count commands
int return_commands_number(FILE *fp){
	char line[MAXARGS];
	int lines=0;
    // file open error !
    if (fp == NULL){ //no file.
		return 0;
	}

    //file reading
    while (fgets(line, sizeof(line), fp)) {
		strcpy(command_history[lines],line);
        lines++;
    }

    //file close
    fclose(fp);

	return lines;
    
}


void handle_sigint(int sig){
	pid_t pid = fgpid(jobs);
	Sio_puts("\n");
	if (pid > 0){
		Kill(-pid,SIGINT);
	}	

	return;
}

void handle_sigtstp(int sig){
	
	pid_t pid = fgpid(jobs); // 현재 실행 중인 foreground job의 프로세스 그룹 ID를 가져옴
	Sio_puts("\n");
    if (pid > 0) {
		getjobpid(jobs, pid)->state = ST;
        kill(-pid, SIGTSTP); // 해당 프로세스 그룹 ID에 SIGTSTP 시그널을 보냄
    }
	return;
}

void pipeLine(char ***args, int pipeline_number) {
    int n = pipeline_number + 1; // commands_number
    int i, j, k, status;
    int pipefd[n - 1][2];
    pid_t pid[n];

    for (i = 0; i < n; i++) {
		
        if (i < n - 1 && pipe(pipefd[i]) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }
        pid[i] = fork();
        if (pid[i] == -1) // error
        {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid[i] == 0) { // child process
            if (i > 0) { // not first
                Close(pipefd[i - 1][1]);
                Dup2(pipefd[i - 1][0], STDIN_FILENO);
                Close(pipefd[i - 1][0]);
            }
            if (i < n - 1) { // not last
                Close(pipefd[i][0]);
                Dup2(pipefd[i][1], STDOUT_FILENO);
                Close(pipefd[i][1]);
            }
            if (execvp(args[i][0], args[i]) < 0) {
                printf("%s: Command not found.\n", args[i][0]);
                exit(0);
            }
        }

		if (i > 0) { // not first
            Close(pipefd[i - 1][0]);
            Close(pipefd[i - 1][1]);
        }

		
    }

	
    for (i = 0; i < n; i++) {
		
        Waitpid(pid[i], &status, 0);
    }

    return;
}


void pipeLine2(char ***args, int pipeline_number) {
    int n = pipeline_number + 1; // commands_number
    int i, j, k, status;
    int pipefd[n - 1][2];
    pid_t pid[n];

    for (i = 0; i < n; i++) {
		
        if (i < n - 1 && pipe(pipefd[i]) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }
        pid[i] = fork();
        if (pid[i] == -1) // error
        {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid[i] == 0) { // child process
            if (i > 0) { // not first
                Close(pipefd[i - 1][1]);
                Dup2(pipefd[i - 1][0], STDIN_FILENO);
                Close(pipefd[i - 1][0]);
            }
            if (i < n - 1) { // not last
                Close(pipefd[i][0]);
                Dup2(pipefd[i][1], STDOUT_FILENO);
                Close(pipefd[i][1]);
            }
            if (execvp(args[i][0], args[i]) < 0) {
                printf("%s: Command not found.\n", args[i][0]);
                exit(0);
            }
        }

		if (i > 0) { // not first
            Close(pipefd[i - 1][0]);
            Close(pipefd[i - 1][1]);
        }

		
    }

	
    
    return;
}


//argc pipeline number
int count_argc(char **argv){
	int n = 0;

	while(argv[n] != NULL){
		n++;
	}//n = argc
	n++;
	return n;

}
//count pipeline
int count_pipeline(char **argv, int argc){
	int i;
	int n=0;
	for (i=0; i<argc-1; ++i){
		if (strcmp(argv[i], "|") == 0){
			n++;
		}
	}
	
	return n;
}
char ***parse_cmds(char **argv, int argc) {

    char ***cmds = malloc( argc* sizeof(char **));
	for (int i=0; i<argc; i++){
		cmds[i] = malloc((MAXARGS) * sizeof(char *));
		for (int j=0; j<MAXARGS; j++){
			cmds[i][j] = NULL;
		}
	}
    int i = 0, j = 0, k = 0;
    while (i < argc) {
        //cmds[j] = malloc(MAXARGS * sizeof(char *));
        while ( argv[i] != NULL && argv[i] != '\"' &&argv[i] != '\'' && strcmp(argv[i], "|") != 0) {
            cmds[j][k++] = argv[i++];
			
        }
        cmds[j++][k] = NULL;
        i++;
        k = 0;
		
    }
    cmds[j] = NULL;
    return cmds;

}
void free_cmd(char ***cmd, int argc){

	for (int i=0; i<argc; i++){
		free(cmd[i]);
	}
	free(cmd);


}
/*bg, fg 처리하는 함수 
bg % 4
fg % 5
*/
void do_bgfg(char **argv){
	struct job_t *jobp=NULL;
    char *id=argv[1];

	// 다음 명령어가 없는 경우 
	if (id == NULL) {
		printf("%s command requires PID or %%jobid argument\n", argv[0]);
		return;
    }   

	if (id[0] == '%') {
		jobp = getjobjid(jobs, atoi(&id[1]));

		if (jobp == NULL) {
			printf("No Such Job\n");
			return;
		}
    } //만약 %가 없는 경우
    else if (isdigit(id[0])) {
		pid_t pid = atoi(id);
		if (!(jobp = getjobpid(jobs, pid))) {
			printf("(%d): No such process\n", pid);
			return;
		}
	}//
    else {
		printf("%s: argument must be a PID or %%jobid\n", argv[0]);
		return;
    }
	Kill(-jobp->pid, SIGCONT);

	

    if (!strcmp(argv[0], "bg")) {
		if(jobp->state == BG) printf("already background!\n");
		else{
			jobp->state = BG;
			printf("[%d] running %s\n", jobp->jid,jobp->cmdline);
		} 
		
    }
    else {
		if (jobp->state == FG) printf("already foreground!\n");
		else{
			jobp->state = FG;
			printf("[%d] running %s\n", jobp->jid,jobp->cmdline);
			waitfg(jobp->pid);
		}
    }

    return;

}

void do_jobs() 
{
    struct job_t *jobp;

    for (int i = 1; i <= MAXJOBS; i++) {
		jobp = getjobjid(jobs, i);
		if (jobp != NULL) {
			//printf("jobs id %d %d %s\n",jobp->pid,jobp->jid,jobp->cmdline);
			switch (jobp->state) {
				case BG:
					printf("[%d]\trunning  \t%s\n", jobp->jid, jobp->cmdline);
					break;
				case FG:
					//printf("running ");
					break;
				case ST:
					printf("[%d]\tsuspended  \t%s\n", jobp->jid, jobp->cmdline);
					break;
				default:
					;
					
			}
			
		}
    }
    return;
}

void waitfg(pid_t pid)
{
    while (pid == fgpid(jobs))
		sleep(1);
    return;
}

void sigchld_handler(int sig)
{
    pid_t pid;
    int status;

	while ((pid = waitpid(-1, &status, WNOHANG | WCONTINUED)) > 0) {
		if (WIFEXITED(status) || WIFSIGNALED(status)) {
			for(int i = 0; i < MAXJOBS; i++) {
				if(jobs[i].pid == pid && jobs[i].state != UNDEF) {
					jobs[i].state = DONE;
					
				}
			}
		}
	}

    if (pid < 0 && errno != ECHILD) {
        unix_error("sigchld_handler waitpid error");
    }

    return;
}





struct job_t *getjobpid(struct job_t *jobs, pid_t pid)
{
    int i;

    if (pid < 1)
        return NULL;
    for (i = 0; i < MAXJOBS; i++)
        if (jobs[i].pid == pid)
            return &jobs[i];
    return NULL;
}

struct job_t *getjobjid(struct job_t *jobs, int jid)
{
    int i;

    if (jid < 1)
        return NULL;

    for (i = 0; i < MAXJOBS; i++)
        if (jobs[i].jid == jid)
            return &jobs[i];

    return NULL;
}


void do_kill(char **argv)
{
	if (argv[1] == NULL) {
            printf("kill: argument must be a PID or %%jobid\n");
            return;
    }

	int jid_or_pid;
	pid_t pid;
	
	if (argv[1][0] == '%') {
		jid_or_pid = atoi(&argv[1][1]);
		struct job_t *job = getjobjid(jobs, jid_or_pid);
		if (!job ) {
			printf("%%%d: No Such Job\n", jid_or_pid);
			return;
		}
		pid = job->pid;
	} else {
		pid = atoi(argv[1]);
		if (!getjobpid(jobs, pid)) {
			printf("(%d): No Such Process\n", pid);
			return;
		}
	}

	kill(pid,SIGKILL);
	
	return;
	
}

void input_cd(char ** cmd){
	if (cmd[1]){
		if (chdir(cmd[1]))
			perror("cd");

	}
	else chdir(getenv("HOME"));

}
/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
	if (!strcmp(argv[0] , "exit"))
		exit(0);
	else if (!strcmp(argv[0], "quit")) /* quit command */
		exit(0);  
	else if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	else if (!strcmp(argv[0], "jobs")){
		do_jobs();
		return 1;
	}
	else if (!strcmp(argv[0], "fg")){
		do_bgfg(argv);
		return 1;
	}
	else if (!strcmp(argv[0], "bg")){
		do_bgfg(argv);
		return 1;
	}
	else if (!strcmp(argv[0], "kill")){
		do_kill(argv);
		return 1;
	}
	else if (!strcmp(argv[0] , "cd")){
		input_cd(argv);
		return 1;
	}
	//history command 
	else if (!strcmp(argv[0] , "history")){
		print_history();
		return 1;
	}//!! command
	else if (!strcmp(argv[0] , "!!")){
		
		char *pre_com = get_pre_command();
		if (pre_com != NULL) eval(pre_com);
		return 1;
	}
	else if (argv[0][0] == '!'){
		char *num_str = argv[0]+1;
		if (strlen(num_str) == 0 ){
			printf("Inavlid number.\n");
			return 0;
		}
		for (int i=0; i<strlen(num_str); i++){
			if(!isdigit(num_str[i])){
				printf("Invalid number.\n");
				return 0;
			}
		}
		int command_number = atoi(num_str);
		char *command = get_command_by_num(command_number);
		if (command != NULL) eval(command);
		return 1;

	}
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv, char*jobscmdline) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */

	

    buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

    /* Build the argv list */
    argc = 0;
	while ((delim = strchr(buf, ' '))) {
		
		//' , " , ' ' argument 추출
		if (*buf == '\''){
			buf++;
			delim = strchr(buf,'\'');
		}
		else if (*buf == '\"'){
			buf++;
			delim = strchr(buf,'\"');
		}
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
		return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0)
		argv[--argc] = NULL;
	

	for(int i=0; i<argc; ++i){
		char arg[MAXLINE];
        sprintf(arg, "%s ", argv[i]);
        strcat(jobscmdline, arg);
	}


	
    return bg;
}
/* $end parseline */


