/* $begin shellmain */
#include "csapp.h"
#include<errno.h>
#define MAXARGS   128
#define MAX_HISTORY 1024
#define MAX_COMMAND 1024


/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 
char command_history[MAX_HISTORY][MAX_COMMAND];
int num_commands= 0;

FILE *wfp;
char ***parse_cmds(char **argv,int argc);


//history 를 출력하는 함수
void print_history(){

	for (int i=1; i<=num_commands; i++){
		printf("%d  %s",i,command_history[i-1]);
	}


}
//previous commands 를 반환하는 함수
char *get_pre_command(){

	if (num_commands==0){
		printf("No commands\n");
		return NULL;
	}
	return command_history[num_commands-1];
}

//number에 맞는 history를 반환하는 함수
char *get_command_by_num(int num){

	if (num <1 || num >= num_commands){

		printf("Invalid number.\n");
		return NULL;

	}
	return command_history[num-1];


}

//history에 저장
void add_command_to_history(char *command){
	
	if (!strcmp(command_history[num_commands-1] , command)) return; 
	strcpy(command_history[num_commands],command);
	setbuf(wfp, NULL);
	fprintf(wfp,"%s",command);
	num_commands++;


}

//history: count commands
int return_commands_number(FILE *fp){
	char line[MAXARGS];
	int lines=0;
    // file open error !
    if (fp == NULL){ //no file.
		return 0;
	}

    //file reading
    while (fgets(line, sizeof(line), fp)) {
		strcpy(command_history[lines],line);
        lines++;
    }

    //file close
    fclose(fp);

	return lines;
    
}


void handle_sigint(int sig){
	printf("SIGINT IGNORE\n");
}

void handle_sigtstp(int sig){
	printf("SIGTSTP IGNORE\n");
}
void pipeLine(char ***args, int pipeline_number) {
    int n = pipeline_number + 1; // commands_number
    int i, j, k, status;
    int pipefd[n - 1][2];
    pid_t pid[n];

    for (i = 0; i < n; i++) {
		
        if (i < n - 1 && pipe(pipefd[i]) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }
        pid[i] = fork();
        if (pid[i] == -1) // error
        {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid[i] == 0) { // child process
            if (i > 0) { // not first
                Close(pipefd[i - 1][1]);
                Dup2(pipefd[i - 1][0], STDIN_FILENO);
                Close(pipefd[i - 1][0]);
            }
            if (i < n - 1) { // not last
                Close(pipefd[i][0]);
                Dup2(pipefd[i][1], STDOUT_FILENO);
                Close(pipefd[i][1]);
            }
            if (execvp(args[i][0], args[i]) < 0) {
                printf("%s: Command not found.\n", args[i][0]);
                exit(0);
            }
        }

		if (i > 0) { // not first
            Close(pipefd[i - 1][0]);
            Close(pipefd[i - 1][1]);
        }

		
    }

	
    for (i = 0; i < n; i++) {
        Waitpid(pid[i], &status, 0);
    }

    return;
}
//argc pipeline number
int count_argc(char **argv){
	int n = 0;

	while(argv[n] != NULL){
		n++;
	}//n = argc
	n++;
	return n;

}
//count pipeline
int count_pipeline(char **argv, int argc){
	int i;
	int n=0;
	for (i=0; i<argc-1; ++i){
		if (strcmp(argv[i], "|") == 0){
			n++;
		}
	}
	
	return n;
}
char ***parse_cmds(char **argv, int argc) {

    char ***cmds = malloc( argc* sizeof(char **));
	for (int i=0; i<argc; i++){
		cmds[i] = malloc((MAXARGS) * sizeof(char *));
		for (int j=0; j<MAXARGS; j++){
			cmds[i][j] = NULL;
		}
	}
    int i = 0, j = 0, k = 0;
    while (i < argc) {
        //cmds[j] = malloc(MAXARGS * sizeof(char *));
        while ( argv[i] != NULL && argv[i] != '\"' &&argv[i] != '\'' && strcmp(argv[i], "|") != 0) {
            cmds[j][k++] = argv[i++];
			
        }
        cmds[j++][k] = NULL;
        i++;
        k = 0;
		
    }
    cmds[j] = NULL;
    return cmds;

}
void free_cmd(char ***cmd, int argc){

	for (int i=0; i<argc; i++){
		free(cmd[i]);
	}
	free(cmd);


}
int main() 
{
    char cmdline[MAXLINE]; /* Command line */
	Signal(SIGINT,handle_sigint);
	Signal(SIGTSTP,handle_sigtstp);

	FILE *ofp;
    char filename[] = "history.txt";

    //file open 
    ofp = fopen(filename, "r");
	wfp = fopen(filename, "a");

	num_commands = return_commands_number(ofp);

    while (1) {
		/* Read */
		printf("CSE4100-MP-P2> ");                   
		fgets(cmdline, MAXLINE, stdin); 
		if (feof(stdin))
			exit(0);

		/* Evaluate */
		eval(cmdline);
    } 

	fclose(ofp);
	fclose(wfp);
}
/* $end shellmain */
  
/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
	char ***cmd; // phase2
	int argc;
	int pipeline_num;

    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    
    strcpy(buf, cmdline);
    bg = parseline(buf, argv); 
    if (argv[0] == NULL)  
		return;   /* Ignore empty lines */

    if (argv[0][0] != '!') add_command_to_history(cmdline); //history 명령어인 !는 저장x

	if (!builtin_command(argv)) {
		//quit -> exit(0), & -> ignore, other -> run
		
		argc = count_argc(argv);
		pipeline_num = count_pipeline(argv,argc);

		if (pipeline_num){ //go pipeline 
			cmd = parse_cmds(argv, argc);
			pipeLine(cmd,pipeline_num);
			free_cmd(cmd, argc);
		}
		else{
			if ((pid = fork()) == 0 ){ // child process 

			if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
				printf("%s: Command not found.\n", argv[0]);
				exit(0);
			}
		}
		}
		
	/* Parent waits for foreground job to terminate */
	if (!bg ){ 
	    int status;
		if(waitpid(pid,&status,0)<0 && !pipeline_num) unix_error("waitfg: waitpid error");
	}
	else//when there is backgrount process!
	    printf("%d %s", pid, cmdline);
    }

	
    return;
}



void input_cd(char ** cmd){
	if (cmd[1]){
		if (chdir(cmd[1]))
			perror("cd");

	}
	else chdir(getenv("HOME"));

}
/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
	if (!strcmp(argv[0] , "exit"))
		exit(0);
	else if (!strcmp(argv[0], "quit")) /* quit command */
		exit(0);  
	else if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	else if (!strcmp(argv[0] , "cd")){
		input_cd(argv);
		return 1;
	}
	//history command
	else if (!strcmp(argv[0] , "history")){
		
		print_history();
		return 1;
	}//!! command
	else if (!strcmp(argv[0] , "!!")){
		
		char *pre_com = get_pre_command();
		if (pre_com != NULL) eval(pre_com);
		return 1;
	}
	else if (argv[0][0] == '!'){
		char *num_str = argv[0]+1;
		if (strlen(num_str) == 0 ){
			printf("Inavlid number.\n");
			return 0;
		}
		for (int i=0; i<strlen(num_str); i++){
			if(!isdigit(num_str[i])){
				printf("Invalid number.\n");
				return 0;
			}
		}
		int command_number = atoi(num_str);
		char *command = get_command_by_num(command_number);
		if (command != NULL) eval(command);
		return 1;

	}
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */

    buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

    /* Build the argv list */
    argc = 0;
	while ((delim = strchr(buf, ' '))) {
		
		//' , " , ' ' argument 추출
		if (*buf == '\''){
			buf++;
			delim = strchr(buf,'\'');
		}
		else if (*buf == '\"'){
			buf++;
			delim = strchr(buf,'\"');
		}
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
		return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0)
		argv[--argc] = NULL;

    return bg;
}
/* $end parseline */


