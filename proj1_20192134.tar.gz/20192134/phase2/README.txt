[system programming lecture]

-project 2 baseline

csapp.{c,h}
        CS:APP3e functions
shellex.c
        pipeline shell example
shellex example:
        'cat filename | grep -i "asdf" | sort -rmdir'
        'ls | grep cs'
compile:
        1. make
        2. ./shellex

