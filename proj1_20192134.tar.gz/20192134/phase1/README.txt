[system programming lecture]

-project 1 baseline

csapp.{c,h}
        CS:APP3e functions

shellex.c
        Simple shell example
shellex 
        command examples :

        'cat filename',
        'touch filename',
        'cd directory',
        'echo',
        'mkdir directory',
        'rmdir directory',
        'history',
        '!!',
        '!#',
        'exit'
compile:
        1. make
        2. ./shellex



