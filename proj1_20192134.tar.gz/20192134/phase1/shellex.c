/* $begin shellmain */
#include "csapp.h"
#include<errno.h>
#define MAXARGS   128
#define MAX_HISTORY 1024
#define MAX_COMMAND 1024


/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 
char command_history[MAX_HISTORY][MAX_COMMAND];
int num_commands= 0;

FILE *wfp;

//history 를 출력하는 함수
void print_history(){

	for (int i=1; i<=num_commands; i++){
		printf("%d  %s",i,command_history[i-1]);
	}


}
//previous commands 를 반환하는 함수
char *get_pre_command(){

	if (num_commands==0){
		printf("No commands\n");
		return NULL;
	}
	return command_history[num_commands-1];
}

//number에 맞는 history를 반환하는 함수
char *get_command_by_num(int num){

	if (num <1 || num >= num_commands){

		printf("Invalid number.\n");
		return NULL;

	}
	return command_history[num-1];


}

//history에 저장
void add_command_to_history(char *command){
	//이전 명령어와 동일하면 처리 x
	if (!strcmp(command_history[num_commands-1] , command)) return; 

	strcpy(command_history[num_commands],command);
	setbuf(wfp, NULL);
	fprintf(wfp,"%s",command);
	num_commands++;


}
pid_t get_pid, main_pid;

void handle_sigint(int sig){
	printf("SIGINT IGNORE\n");
}

void handle_sigtstp(int sig){

	printf("SIGTSTP IGNORE\n");
}

//history: count commands
int return_commands_number(FILE *fp){
	char line[MAXARGS];
	int lines=0;
    
	if (fp == NULL){ //no file.
		return 0;
	}

    //file reading
    while (fgets(line, sizeof(line), fp)) {
		strcpy(command_history[lines],line);
        lines++;
    }

    //file close
    fclose(fp);

	return lines;
    
}


int main() 
{
    char cmdline[MAXLINE]; /* Command line */
	Signal(SIGINT,handle_sigint);
	Signal(SIGTSTP,handle_sigtstp);

	FILE *ofp;
    char filename[] = "history.txt";

    //file open 
    ofp = fopen(filename, "r");
	wfp = fopen(filename, "a");


	num_commands = return_commands_number(ofp);
	
    while (1) {
	/* Read */
	printf("CSE4100-MP-P1> ");                   
	fgets(cmdline, MAXLINE, stdin); 
	if (feof(stdin))
	    exit(0);

	/* Evaluate */
	eval(cmdline);
    } 

	fclose(ofp);
	fclose(wfp);
}
/* $end shellmain */
  
/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    
    strcpy(buf, cmdline);
    bg = parseline(buf, argv); 
    if (argv[0] == NULL)  
		return;   /* Ignore empty lines */

    if (argv[0][0] != '!') add_command_to_history(cmdline); //history 명령어인 !는 저장x

	if (!builtin_command(argv)) {
		//quit -> exit(0), & -> ignore, other -> run
		if ((pid = fork()) == 0 ){ // child process 

			if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
				printf("%s: Command not found.\n", argv[0]);
				exit(0);
			}
		}


	/* Parent waits for foreground job to terminate */
	if (!bg){ 
	    int status;
		if(waitpid(pid,&status,0)<0) unix_error("waitfg: waitpid error");
	}
	else//when there is backgrount process!
	    printf("%d %s", pid, cmdline);
    }
    return;
}

void input_cd(char ** cmd){
	if (cmd[1]){
		if (chdir(cmd[1]))
			perror("cd");

	}
	else chdir(getenv("HOME"));

}
/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
	if (!strcmp(argv[0] , "exit"))
		exit(0);
	else if (!strcmp(argv[0], "quit")) /* quit command */
		exit(0);  
	else if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	else if (!strcmp(argv[0] , "cd")){
		input_cd(argv);
		return 1;
	}
	//history command
	else if (!strcmp(argv[0] , "history")){
		
		print_history();
		return 1;
	}//!! command
	else if (!strcmp(argv[0] , "!!")){
		
		char *pre_com = get_pre_command();
		if (pre_com != NULL) eval(pre_com);
		return 1;
	}
	else if (argv[0][0] == '!'){
		char *num_str = argv[0]+1;
		if (strlen(num_str) == 0 ){
			printf("Inavlid number.\n");
			return 0;
		}
		for (int i=0; i<strlen(num_str); i++){
			if(!isdigit(num_str[i])){
				printf("Invalid number.\n");
				return 0;
			}
		}
		int command_number = atoi(num_str);
		char *command = get_command_by_num(command_number);
		if (command != NULL) eval(command);
		return 1;

	}
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */

    buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

    /* Build the argv list */
    argc = 0;
	while ((delim = strchr(buf, ' '))) {
		
		//' , " , ' ' argument 추출
		if (*buf == '\''){
			buf++;
			delim = strchr(buf,'\'');
		}
		else if (*buf == '\"'){
			buf++;
			delim = strchr(buf,'\"');
		}
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */
		return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0)
		argv[--argc] = NULL;

    return bg;
}
/* $end parseline */


